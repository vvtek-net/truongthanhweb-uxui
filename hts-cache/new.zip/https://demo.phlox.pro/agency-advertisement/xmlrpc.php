<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="https://demo.phlox.pro/">here</a>.</p>
<hr>
<address>Apache/2.4.52 (Ubuntu) OpenSSL/3.0.2 Server at demo.phlox.pro Port 443</address>
</body></html>
